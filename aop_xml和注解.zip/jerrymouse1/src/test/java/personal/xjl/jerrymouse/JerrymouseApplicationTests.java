package personal.xjl.jerrymouse;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import personal.xjl.jerrymouse.spring.Car;
import personal.xjl.jerrymouse.spring.Human;
import personal.xjl.jerrymouse.spring.MyMath;

@SpringBootTest
class JerrymouseApplicationTests {
   //自动注入，装配
//    @Autowired
//    StudentMapper studentMapper;
//    @Autowired
//    Student zhangsan;
//    @Autowired
//           @Qualifier("zhangsan")
//    Human human;
    @Autowired
    Car myCar;
    @Test
    void contextLoads() {
//        Student student=new Student();
//        student.setName("musi");
//        student.setPassword("musi");
//        student.setSex(0);
//        student.setClazz("21java3");
//        studentMapper.insert(student);
//        List<Student> students=studentMapper.queryAll();
//        students.forEach(e-> System.out.println(e));
//        zhangsan.setName("zhangsan1");

//        System.out.println(human);
//        human.introduce();
//        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("beans.xml");
//        Car c1 = (Car) applicationContext.getBean("myBMW");
//        System.out.println(c1);
//        Car c2 = (Car) applicationContext.getBean("benz");
//        System.out.println(c2.getType());
//        Human h1 = (Human) applicationContext.getBean("lisi");
//        System.out.println(h1);
//        Human h2 = (Human) applicationContext.getBean("wangwu");
//        System.out.println(h2);

        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("aop.xml");
//        MyMath myMath = applicationContext.getBean("target", MyMath.class);
//        myMath.setN1(2);
//        myMath.setN2(2);
//        myMath.add();
//        myMath.subtract();
//        myMath.mul();
//        myMath.dev();
        MyMath myMath = applicationContext.getBean("m1", MyMath.class);
        myMath.setN1(2);
        myMath.setN2(2);
        myMath.add();
        myMath.subtract();
        myMath.mul();
        myMath.dev();
    }

}
